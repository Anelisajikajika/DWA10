function increment() {

    document.getElementById('value').stepUp();}
    
    function decrement() {
    
    document.getElementById('value').stepDown(); }