document.addEventListener('DOMContentLoaded', () => {
  const counterElement = document.getElementById('counter');
  const addButton = document.getElementById('add');
  const subtractButton = document.getElementById('subtract');
  const resetButton = document.getElementById('reset');
  const messageElement = document.getElementById('message');

  let counter = 0;

  const updateCounter = (newCounter) => {
      counter = newCounter;
      counterElement.textContent = counter;
  };

  const showMessage = (message) => {
      messageElement.textContent = message;
      setTimeout(() => {
          messageElement.textContent = '';
      }, 2000);
  };

  addButton.addEventListener('click', () => {
      updateCounter(counter + 1);
  });

  subtractButton.addEventListener('click', () => {
      if (counter > 0) {
          updateCounter(counter - 1);
      }
  });

  resetButton.addEventListener('click', () => {
      updateCounter(0);
      showMessage('The counter has been reset');
  });

  // Initialize counter
  updateCounter(0);
});
